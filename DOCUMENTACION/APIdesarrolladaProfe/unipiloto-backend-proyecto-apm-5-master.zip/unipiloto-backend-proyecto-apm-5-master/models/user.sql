INSERT INTO user (id, email, password, firstname, lastname, phone) VALUES (2, 'admin1@admin.co', '1234', 'Admin', 'Servers', '123496968');
INSERT INTO user (id, email, password, firstname, lastname, phone) VALUES (3, 'admin2@admin.co', '1234', 'Administración 2', 'Servers', '12345444848');
INSERT INTO user (id, email, password, firstname, lastname, phone) VALUES (4, 'admin1@admin.com', 'admin', 'admin1', 'Server', '117117');
INSERT INTO user (id, email, password, firstname, lastname, phone) VALUES (5, 'admin2@admin.com', 'admin', 'Admin 2', 'Server ', '448866332');
